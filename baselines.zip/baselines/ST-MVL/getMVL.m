function MVL = getMVL(GS,LS,W,Y)

    MVL = zeros(size(GS,1),size(GS,2));
    W1 = repmat(W(:,1),1,size(GS,2));
    W2 = repmat(W(:,2),1,size(GS,2));
    W3 = repmat(W(:,3),1,size(GS,2));
    MVL = GS.*W2+LS.*W3+W1.*Y;


end