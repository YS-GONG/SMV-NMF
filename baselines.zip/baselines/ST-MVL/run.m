clc
clear

% %load('ABSFull.mat');
% load('Sydneyfull.mat');
% load('DM_174.mat');
% load('DD_174.mat');
% load('Yall.mat');
% load('W.mat');
% %load('W2.mat');


% load('./Flowdata/FlowData.mat');
% 
% load('./Flowdata/DM.mat');
% load('./Flowdata/DD.mat');
% 
% load('./Flowdata/W.mat');

load('./Brisbane/Brisbanefull.mat');

load('./Brisbane/DM.mat');
load('./Brisbane/DD.mat');
load('W22.mat');

D = [D1, D2, D3, D4];
[D1,ps] = mapminmax(D',0,10);
D1 = D1';
Dv = D1(:,[1:22,44:65,88:112,138:185]);
m1 = [22, 22, 25, 48];
Dt = D1(:,[23:43,66:87,113:137,186:234]);
m2 = [21, 22, 25, 49];

alpha = 2;
w = 7;%%window size, odd number, w <= size(D,2)

for i = 1:7
    %Y = Yall(:,:,i);
    Y = getmiss(D1,i/10);
    Y_ba = ones(size(Y,1),size(Y,2))-Y;


    GS = IDW(D1,Y,DD,DM,alpha);
    LS = UCF(D1,Y,w,DD,DM,alpha);
    MVL = getMVL(GS,LS,W22,Y_ba);

%     [H1,H2] = nmf(D,Y,6,1000);
%     NMF = H1*H2;
%     MVL_NMF = getMVL(GS,NMF.*Y_ba,W2,Y_ba);


    Avg = (GS+LS)./2;
    %MVL = getMVL(GS,LS,D);







    Ssum = (Y_ba.*(D1-GS)).^2;
    Ssum2 = (Y_ba.*D1-Y_ba.*LS).^2;
    Ssum3 = (Y_ba.*D1-Y_ba.*MVL).^2;
    Ssum4 = (Y_ba.*D1-Y_ba.*Avg).^2;
    
    

    r_GS(i)=sqrt(sum(Ssum(:))/length(find(Y_ba==1)));
    r_LS(i)=sqrt(sum(Ssum2(:))/length(find(Y_ba==1)));
    r_MVL(i)=sqrt(sum(Ssum3(:))/length(find(Y_ba==1)));
    r_Avg(i)=sqrt(sum(Ssum4(:))/length(find(Y_ba==1))); 
    MRE_GS(i) = sum(sum(abs(Y_ba.*D1-Y_ba.*GS)))./sum(sum(Y_ba.*D1));
    MRE_LS(i) = sum(sum(abs(Y_ba.*D1-Y_ba.*LS)))./sum(sum(Y_ba.*D1));
    MRE_MVL(i) = sum(sum(abs(Y_ba.*D1-Y_ba.*MVL)))./sum(sum(Y_ba.*D1));
    MRE_Avg(i) = sum(sum(abs(Y_ba.*D1-Y_ba.*Avg)))./sum(sum(Y_ba.*D1));
end    