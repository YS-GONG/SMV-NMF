function Y = getmiss(D,rate)

    q = size(D,1);
    p = size(D,2);
    Y = zeros(q,p);

    n = round(q*p*rate);

    for i = 1:q
        j = randi([1,p],1,1);
        Y(i,j) = 1;       
    end
    
    for k = 1:p
        
        l = randi([1,q],1,1);
        Y(l,k) = 1;
    end
    
    n1 = q*p-n-length(find(Y==1));
    W1 = find(Y==0);
    rand = randperm(length(W1));
    W2 = W1(rand(1:n1));
    Y(W2)=1;
    
    
   
%     D1 = ones(1,q*p);
%     
%     Rand = randperm(q*p);
%     
%     P = Rand(1:n);
%     
%     D1(P)=0;
%     
%     D2 = reshape(D1,[q,p]);
%     
%     flag=1;
%     
%     while flag==1
%         
%         if ~isempty(find(sum(D2)==0)) || ~isempty(find(sum(D2,2)==0))
%                 D1 = ones(1,q*p);
%     
%                 Rand = randperm(q*p);
% 
%                 P = Rand(1:n);
% 
%                 D1(P)=0;
% 
%                 D2 = reshape(D1,[q,p]);
%         
%         else
%             flag=0;
%         end
%         
%     end
%     
%     Y = D2;


end