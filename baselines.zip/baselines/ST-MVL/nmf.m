function [W, H] = nmf(V, P, K, MAXITER)
%Euclidean distance
 F = size(V,1);
 T = size(V,2);
 e = 1e-1;
  
rand('seed',0)

W = 1+rand(F, K);

H = 1+rand(K, T);

L0 = norm(P.*(V-W*H),'fro');
  
for i=1:MAXITER
    W = W .* (P.*V*H')./(P.*(W*H)*H'+eps);
    H = H .* (W'*(P.*V))./(W'*(P.*(W*H))+eps) ;
    L1 = norm(P.*(V-W*H),'fro');
    LL = abs(L0-L1)/L0;
            if LL<e
                break
            end
    L0=L1;

end
