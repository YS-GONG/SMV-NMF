function LS = UCF(V,Y,w,DD,DM,alpha) 

    [p1, p2] = find(Y == 0);
    P = [p1,p2];
    LS = zeros(size(Y,1),size(Y,2));
    d = round((w-1)/2);
    
    GS = IDW(V,Y,DD,DM,alpha);
    
    for i = 1:size(P,1)
        if P(i,2) < d+1 
            Y_l = Y(:,1:P(i,2)+d);
            V_l = V(:,1:P(i,2)+d);
            GS_l = GS(:,1:P(i,2)+d);
            p_l = size(Y_l,2)-d;
        elseif P(i,2) + d > size(Y,2)
            Y_l = Y(:,P(i,2)-d:end);
            V_l = V(:,P(i,2)-d:end);
            GS_l = GS(:,P(i,2)-d:end);
            p_l = d+1;
        else 
            Y_l = Y(:,P(i,2)-d:P(i,2)+d);
            V_l = V(:,P(i,2)-d:P(i,2)+d);
            GS_l = GS(:,P(i,2)-d:P(i,2)+d);
            p_l = d+1;
        end
        
        for j = setdiff((1:size(Y,1)),P(i,1))
            
            in = and(Y_l(P(i,1),:),Y_l(j,:));
            if isempty(find(in==1))
                s1 = GS_l(P(i,1),:)+V_l(P(i,1),:);
                s2 = GS_l(j,:)+V_l(j,:);
                sim(j) = getsim(s1,s2);
            else
                s1 = V_l(P(i,1),:).*in;
                s2 = V_l(j,:).*in;
                sim(j) = getsim(s1,s2,in);
            end
        end
        
        v_ls = sum(Y_l(:,p_l).*sim'.*V_l(:,p_l))/sum(Y_l(:,p_l).*sim');
        
        LS(P(i,1),P(i,2)) = v_ls;
    end
                
            
            

end