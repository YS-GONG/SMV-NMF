clc
clear

% load('ABStrain.mat');
% 
% load('DM_174.mat');
% load('DD_174.mat');
% load('Yall.mat');


% load('./Flowdata/TrainFlowData1.mat');
% 
% load('./Flowdata/DM.mat');
% load('./Flowdata/DD.mat');


load('./Brisbane/Brisbanefull.mat');

load('./Brisbane/DM.mat');
load('./Brisbane/DD.mat');


D = [D1, D2, D3, D4];

[D1,ps] = mapminmax(D',0,10);
D1 = D1';
Dv = D1(:,[1:22,44:65,88:112,138:185]);
m1 = [22, 22, 25, 48];
Dt = D1(:,[23:43,66:87,113:137,186:234]);
m2 = [21, 22, 25, 49];

alpha = 2;
w = 7;%%window size, odd number, w <= size(D,2)

%Y = Yall(:,:,9);
Y = getmiss(D1,0.5);
Y_ba = ones(size(Y,1),size(Y,2))-Y;


GS = IDW(D1,Y,DD,DM,alpha);
LS = UCF(D1,Y,w,DD,DM,alpha);
[MVL1,W] = trainMVL(GS,LS,D1);


% [H1,H2] = nmf(D,Y,6,100);
% NMF = H1*H2;
% [MVL2,W2] = trainMVL(GS,NMF.*Y_ba,D);







Ssum = (Y_ba.*D1-Y_ba.*GS).^2;
Ssum2 = (Y_ba.*D1-Y_ba.*LS).^2;
Ssum3 = (Y_ba.*D1-Y_ba.*MVL1).^2;
%Ssum4 = (Y_ba.*Dv-Y_ba.*MVL2).^2;

RMSE=sqrt(sum(Ssum(:))/length(find(Y_ba==1)));
RMSE2=sqrt(sum(Ssum2(:))/length(find(Y_ba==1)));
RMSE3=sqrt(sum(Ssum3(:))/length(find(Y_ba==1)));
%RMSE4=sqrt(sum(Ssum4(:))/length(find(Y_ba==1)));