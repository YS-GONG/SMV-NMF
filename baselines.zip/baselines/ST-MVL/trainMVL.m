function [MVL,W] = trainMVL(GS,LS,D)
    MVL = zeros(size(D,1),size(D,2));
    for i = 1:size(D,1)
        
        gs_p = find(GS(i,:)~=0);
        gs = GS(i,:);
        gs = gs(gs_p);
        
        ls = LS(i,:);
        ls = ls(gs_p);        
        
        y = D(i,:);        
        y = y(gs_p)';
        
        F = ones(1,size(y,1));
        
        X = [F',gs',ls'];
        
        b=regress(y,X);
        
        MVL(i,:) = (b(2).*GS(i,:)+b(3).*LS(i,:)+b(1)).*(GS(i,:)~=0);
        W(i,:) = b';
    end
    
    
    
    

end