function value = getsim(s1,s2,in)

    if nargin==2
        value = 1/sqrt(sum((s1-s2).^2)/length(s1)+1e-8);
    else
        value = 1/sqrt(sum((s1-s2).^2)/length(find(in==1))+1e-8);
    end
    

end