function GS = IDW(V,Y,DD,DM,alpha)
    [p1, p2] = find(Y == 0);
    P = [p1,p2];
    GS = zeros(size(Y,1),size(Y,2));
    
    s=0;
    n=0;
    for i = 1:size(P,1)

        d1 = DD(P(i,1),:);
        d1(d1==0)=[];
        d2 = DM(P(i,1),:);
        d2(d2==0)=[];
        d2=d2(2:end);
        
        for j = 1:length(d2)
            if Y(d2(j),P(i,2))~=0
                s = s+V(d2(j),P(i,2))*d1(j)^-alpha;
                n = n+d1(j)^-alpha;
            end
        end
            GS(P(i,1),P(i,2)) = s/n;
            s=0;
            n=0;
    end


end