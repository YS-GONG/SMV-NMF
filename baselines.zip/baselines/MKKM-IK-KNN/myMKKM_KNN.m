clear
clc

load('./Brisbane/Brisbanefull.mat');

load('./Brisbane/L.mat');
load('./Brisbane/DM.mat');
% load('ABSFull.mat');
% load('L.mat');
% load('Yall.mat');

numclass = 8;
sigma = 10;  %%%%%%% parameter of gaussian kernel %%%%
%k = 20;        %%%%%%% latent dimension in nmf %%%%%%%

nk = 6;
la3 = 2^-4;
m = [size(D1,2), size(D2,2), size(D3,2), size(D4,2)];
D = [D1, D2, D3, D4];


%%%%%%%%%%%%%%%%%  normalization  %%%%%%%%%%%%%%%%
[D1,ps] = mapminmax(D',0,10);
D1 = D1';
Dv = D1(:,[1:22,44:65,88:112,138:185]);
m1 = [22, 22, 25, 48];
Dt = D1(:,[23:43,66:87,113:137,186:234]);
m2 = [21, 22, 25, 49];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Ynmis = ones(size(D1,1),size(D1,2));

for rate=1:7

    %Y = Yall(:,:,rate);
    Y = getmiss(D1,rate/10);
    
    Y_ba = ones(size(Y,1),size(Y,2))-Y;
    %nk =6;
    %[X1,~] = mynmf(D,Y,k);
    X2 = initialized_by_KNN(D1,nk,Y,DM);
    
    DD = Y.*D1+Y_ba.*X2;

    %%%%%%%%%%  clustering with incomplete data  %%%%%
    H1 = MKKMIK(DD,Ynmis,m,numclass,sigma,la3,L);

    [Idx,Ccenter,SumD,Distance] = kmeans(H1,numclass);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    DBI = myDBI(Idx,Ccenter,SumD);

    Xknn = getX_KNN(Y,Idx,D1,nk,H1);



 

    Y_ba = ones(size(Y,1),size(Y,2)) - Y;

    Ssum = (Y_ba.*(D1-Xknn)).^2;

    RMSE(rate)=sqrt(sum(Ssum(:))/length(find(Y_ba==1)));
    MRE(rate) = sum(sum(abs(Y_ba.*D1-Y_ba.*Xknn)))./sum(sum(Y_ba.*D1));

end
sum(RMSE)
