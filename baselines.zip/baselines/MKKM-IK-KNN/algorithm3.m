function KH_mean =algorithm3(KH,S)
    a = zeros(1,size(KH,1));
    for i = 1:1:length(S)
        for j = 1:1:length(S{i}.indx)
            KH(S{i}.indx(j),:,i) = a;
            KH(:,S{i}.indx(j),i) = a';
            KH(S{i}.indx(j),S{i}.indx(j),i) = 1;
        end
        ss = sum(sum(KH(:,:,i)))/((size(KH,1)-length(S{i}.indx)));
%        column = sum(KH(:,:,i),2)./(size(KH,3)-length(S{i}.indx));
        KHH = KH(:,:,i);
        KHH(KHH==0)=ss;
        KH(:,:,i) = KHH;
    end
    KH_mean = KH;
end