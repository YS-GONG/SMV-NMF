function H = MKKMIK(D,Y,m,numclass,sigma,la3,L)

    for i = 1:size(m,2)
        KH(:,:,i) = convert2kernel(D(:,1:m(i)),sigma);
        D(:,1:m(i))=[];
    end
    S = getmisskernel(Y,m);
    
    algorithm_choose1 = 'algorithm3';
    qnorm = 2;
    
    KH = center_norm2(KH,S);
    
    [H,beta,~,KM] = myabsentmultikernelclustering(KH,S,numclass,qnorm,algorithm_choose1,la3,L);

    

    
end