function DBI = myDBI(Idx,Ccenter,SumD)
    id = unique(Idx)';

    for i = id
        num(i) = length(find(Idx==i));
        avg(i) = SumD(i)/num(i);
    end
    for j = id
        id1 = id;
        id1(j) = [];
        
        for k = id1
            
            A = avg(j) + avg(k);
            B = A/pdist([Ccenter(j,:);Ccenter(k,:)],'euclidean');
            
            S(k) = B;
        end
        
        X(j) = max(S);
    end
    
    DBI = sum(X)/length(id);    
        
        
end
