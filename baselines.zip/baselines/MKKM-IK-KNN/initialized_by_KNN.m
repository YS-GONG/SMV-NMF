function  Xknn = initialized_by_KNN (D1, nk, Y,DM) 

   
    %load('./datasets/DM_174.mat')
    %load('./datasets/Flowdata/DM.mat')
    Xknn = zeros(size(D1,1),size(D1,2));

    X = Y.*D1;
    [p1,p2] = find(Y==0);

    P = [p1,p2];

        for i = 1:length(P)
            ND = DM(P(i,1),1:end);
            ND(ND==0)=[];
            if length(find(Y(:,P(i,2))==1))>=nk
                s = 0;
                flag = 0;
                for j = 1:length(ND)
                    if Y(ND(j),P(i,2))==1&&flag<nk
                        s = s+X(ND(j),P(i,2));
                        flag=flag+1;
                    end
                end 
                Xknn(P(i,1),P(i,2)) = s/nk;
            else
                Xknn(P(i,1),P(i,2)) = sum(X(:,P(i,2)))/length(find(Y(:,P(i,2))==1));
            end

        end
end