function Xknn = getX_KNN(Y,Idx,X,nk,H)%%%%%%calculate Avg mtraix and Distance

    Xknn = zeros(size(X,1),size(X,2));
    
    X = Y.*X;
    [p1,p2] = find(Y==0);
    
    P = [p1,p2];
    
    for i = 1:length(P)
        AA = find(Idx==Idx(P(i,1)));

        
        if length(find(Y(AA,P(i,2))==1))>=nk
            D = pdist2(H(P(i,1),:),H(AA,:));
            [~,W] = sort(D);
            KNN = AA(W);
            s = 0;
            flag = 0;
            for j = 2:length(KNN)
                if Y(KNN(j),P(i,2))==1&&flag<nk
                    s = s+X(KNN(j),P(i,2));
                    flag=flag+1;
                end
            end
            Xknn(P(i,1),P(i,2)) = s/nk;
            
        elseif length((find(Y(AA,P(i,2))==1)))>0&&length((find(Y(AA,P(i,2))==1)))<nk
            D = pdist2(H(P(i,1),:),H);
            [~,W] = sort(D);
            KNN = W;
            s = 0;
            flag = 0;
            for j = 2:length(KNN)
                if Y(KNN(j),P(i,2))==1&&flag<nk
                    s = s+X(KNN(j),P(i,2));
                    flag=flag+1;
                end
            end
            Xknn(P(i,1),P(i,2)) = s/nk;
        else
            Xknn(P(i,1),P(i,2)) = sum(X(:,P(i,2)))/length(find(Y(:,P(i,2))==1));
        end
    end
    

    
end