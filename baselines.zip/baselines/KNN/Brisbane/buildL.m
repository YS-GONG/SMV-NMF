W = zeros(size(DM,1));
for i=1:size(DM,1)
    for j = 2:7
        if DM(i,j)~=0
            W(i,DM(i,j))=1;
        end
        
    end
end

D1 = tril(W,-1)+tril(W,-1)'+diag(diag(W));
D2 = D1-D1.*eye(size(D1));

L=diag(sum(D2))-D2;