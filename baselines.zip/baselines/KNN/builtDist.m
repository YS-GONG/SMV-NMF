% load('distance.mat')
% load('Areas.mat')
% 
% n = 182; %%%number of areas
% DM = zeros(n);
% 
% 
% for i = 1:n:size(Dist,1)-n+1
%     for j = 0:n-1
%         for k = 1:n
%             if ismember(Areas{k},Dist{i+j,2})
%                 DM(((i-1)/n)+1,j+1) = k;
%             end
%         end
%     end
%     
% end


%%%%%%%%%%%% 174 Areas%%%%%%%%%%%%%%%%%%%5

load('distanceFlow.mat')
load('stations.mat')
%load('missAreaId.mat')

n = 178; %%%number of areas
DM = zeros(n);

%Areas(miss) = [];


for i = 1:n:size(Dist,1)-n+1
    for j = 0:n-1
        for k = 1:n%-length(miss)
            if ismember(stations{k},Dist{i+j,2})
                DM(((i-1)/n)+1,j+1) = k;
                DD(((i-1)/n)+1,j+1) = Dist{i+j,3};
            end
        end
    end
    
end