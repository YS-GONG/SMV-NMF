clear
clc

load('./Perth/Perthfull.mat');
load('./Perth/DM.mat');
%load('Yall.mat');

nk = 6;

m = [size(D1,2), size(D2,2), size(D3,2), size(D4,2)];
D = [D1, D2, D3, D4];

%D1 = D;



%%%%%%%%%%%%%%%%  normalization  %%%%%%%%%%%%%%%%
[D1,ps] = mapminmax(D',0,10);
D1 = D1';
Dv = D1(:,[1:22,44:65,88:112,138:185]);
m1 = [22, 22, 25, 48];
Dt = D1(:,[23:43,66:87,113:137,186:234]);
m2 = [21, 22, 25, 49];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for rate = 1:9

    %Y = Yall(:,:,rate);
Y = getmiss(Dt,rate/10);

%Y = getmiss(D1,0.9);

    Xknn = zeros(size(Dt,1),size(Dt,2));

    X = Y.*Dt;
    [p1,p2] = find(Y==0);

    P = [p1,p2];

        for i = 1:length(P)
            ND = DM(P(i,1),1:end);
            ND(ND==0)=[];
            if length(find(Y(:,P(i,2))==1))>=nk
                s = 0;
                flag = 0;
                for j = 1:length(ND)
                    if Y(ND(j),P(i,2))==1&&flag<nk
                        s = s+X(ND(j),P(i,2));
                        flag=flag+1;
                    end
                end 
                Xknn(P(i,1),P(i,2)) = s/nk;
            else
                Xknn(P(i,1),P(i,2)) = sum(X(:,P(i,2)))/length(find(Y(:,P(i,2))==1));
            end

        end


        Y_ba = ones(size(Y,1),size(Y,2)) - Y;

        Ssum = (Y_ba.*(Dt-Xknn)).^2;

        RMSE(rate)=sqrt(sum(Ssum(:))/length(find(Y_ba==1)));
        MRE(rate) = sum(sum(abs(Y_ba.*Dt-Y_ba.*Xknn)))./sum(sum(Y_ba.*Dt));
end   
    
    
    
    
    