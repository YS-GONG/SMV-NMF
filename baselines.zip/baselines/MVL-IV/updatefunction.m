function [W, H] = updatefunction(V, m, P, K, MAXITER,la1,la2)
%Euclidean distance
%for j=1:size(m)
 V1 = V(:,1:m(1));
 V2 = V(:,m(1)+1:m(1)+m(2));
 V3 = V(:,m(1)+m(2)+1:m(1)+m(2)+m(3));
 V4 = V(:,m(1)+m(2)+m(3)+1:end);
 
 P1 = P(:,1:m(1));
 P2 = P(:,m(1)+1:m(1)+m(2));
 P3 = P(:,m(1)+m(2)+1:m(1)+m(2)+m(3));
 P4 = P(:,m(1)+m(2)+m(3)+1:end);
 

 e = 1e-3;
  
rand('seed',0)

W = 1+rand(size(V,1), K);

H1 = 1+rand(K, size(V1,2));
H2 = 1+rand(K, size(V2,2));
H3 = 1+rand(K, size(V3,2));
H4 = 1+rand(K, size(V4,2));

L0 = norm(P1.*(V1-W*H1),'fro')+norm(P2.*(V2-W*H2),'fro')+norm(P3.*(V3-W*H3),'fro')+norm(P4.*(V4-W*H4),'fro')+la1*norm(W,'fro')+la2*(norm(H1,'fro')+norm(H2,'fro')+norm(H3,'fro')+norm(H4,'fro'));
  
for i=1:MAXITER
    W = W .* (P1.*V1*H1'+P2.*V2*H2'+P3.*V3*H3'+P4.*V4*H4')./(P1.*(W*H1)*H1'+P2.*(W*H2)*H2'+P3.*(W*H3)*H3'+P4.*(W*H4)*H4'+la1*W+eps);
    H1 = H1 .* (W'*(P1.*V1))./(W'*(P1.*(W*H1))+la2*H1+eps) ;
    H2 = H2 .* (W'*(P2.*V2))./(W'*(P2.*(W*H2))+la2*H2+eps) ;
    H3 = H3 .* (W'*(P3.*V3))./(W'*(P3.*(W*H3))+la2*H3+eps) ;
    H4 = H4 .* (W'*(P4.*V4))./(W'*(P4.*(W*H4))+la2*H4+eps) ;
    
     L1 = norm(P1.*(V1-W*H1),'fro')+norm(P2.*(V2-W*H2),'fro')+norm(P3.*(V3-W*H3),'fro')+norm(P4.*(V4-W*H4),'fro');
    LL = abs(L0-L1)/L1;
            if LL<e
                break
            end
    L0=L1;
    Z(i) = L1;
end

H = [H1,H2,H3,H4];

plot(Z)