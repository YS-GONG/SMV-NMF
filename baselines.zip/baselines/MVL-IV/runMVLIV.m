clear
clc

load('./Sydney/Sydneyfull.mat');

D = [D1, D2, D3, D4];
m = [size(D1,2), size(D2,2), size(D3,2), size(D4,2)];
%%%%%%%%%%%%%%%%%  normalization  %%%%%%%%%%%%%%%%
[D1,ps] = mapminmax(D',0,10);
D1 = D1';
Dv = D1(:,[1:22,44:65,88:112,138:185]);
m1 = [22, 22, 25, 48];
Dt = D1(:,[23:43,66:87,113:137,186:234]);
m2 = [21, 22, 25, 49];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
k = 35;%25
Iter=500;
la1 = 2^1;%2
la2 = 2^1;%2

for rate=1:7

    %Y = Yall(:,:,rate);
    Y = getmiss(D1,rate/10);
    [W,H] = updatefunction(D1,m,Y,k,Iter,la1,la2);
    X = W*H;
    Y_ba = ones(size(Y,1),size(Y,2)) - Y;
    
    Ssum = (Y_ba.*D1-Y_ba.*X).^2;
    MRE(rate) = sum(sum(abs(Y_ba.*D1-Y_ba.*X)))./sum(sum(Y_ba.*D1));
    RMSE(rate)=sqrt(sum(Ssum(:))/length(find(Y_ba==1)));
end

sum(RMSE(1:7))