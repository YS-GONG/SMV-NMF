clear
clc

%load('ABSFull.mat');
load('FlowData.mat');
load('Yall.mat');

D = [D1 D2 D3 D4];

% %%%%%%%%%%%%%%%%  normalization  %%%%%%%%%%%%%%%%
% [D1,ps] = mapminmax(D',0,10);
% D1 = D1';
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
D1 = D;
for rate=1:9

    %Y = Yall(:,:,rate);
    Y = getmiss(D1,rate/10);
    X = zeros(size(Y,1),size(Y,2));
    Y_ba = ones(size(Y,1),size(Y,2)) - Y;
    mean = sum(Y.*D1)./sum(Y);

    for i = 1:length(mean)
        X((Y(:,i)==0),i) = mean(i);
    end



    Ssum = (Y_ba.*D1-Y_ba.*X).^2;
    SMRE = abs(Y_ba.*D1-Y_ba.*X);
    SD = Y_ba.*D1;
    RMSE(rate)=sqrt(sum(Ssum(:))/length(find(Y_ba==1)));
    MRE(rate) = sum(SMRE(:))/sum(SD(:));

end
%MAE = sum(sum(abs(Y_ba.*D1-Y_ba.*X)))/length(find(Y_ba==1));




