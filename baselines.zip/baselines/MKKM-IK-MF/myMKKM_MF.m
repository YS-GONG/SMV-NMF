clear
clc

load('./Brisbane/Brisbanefull.mat');

load('./Brisbane/L.mat');
load('./Brisbane/DM.mat');
numclass = 8;
sigma = 3;  %%%%%%% parameter of gaussian kernel %%%%
nk = 7;     

la3 = 2^-6;

m = [size(D1,2), size(D2,2), size(D3,2), size(D4,2)];
D = [D1, D2, D3, D4];


%%%%%%%%%%%%%%%%%  normalization  %%%%%%%%%%%%%%%%
[D1,ps] = mapminmax(D',0,10);
D1 = D1';
Dv = D1(:,[1:22,44:65,88:112,138:185]);
m1 = [22, 22, 25, 48];
Dt = D1(:,[23:43,66:87,113:137,186:234]);
m2 = [21, 22, 25, 49];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Ynmis = ones(size(D,1),size(D,2));

for rate=1:7

    Y = getmiss(D,rate/10);
    Y_ba = ones(size(Y,1),size(Y,2))-Y;

    X2 = initialized_by_KNN(D1,nk,Y,DM);
    
    DD = Y.*D1+Y_ba.*X2;

    %%%%%%%%%%  clustering with incomplete data  %%%%%
    H1 = MKKMIK(D1,Ynmis,m,numclass,sigma,la3,L);

    [Idx,Ccenter,SumD,Distance] = kmeans(H1,numclass);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    DBI = myDBI(Idx,Ccenter,SumD);

    Xmf = getX_MF(Y,Idx,D1);



 

    Y_ba = ones(size(Y,1),size(Y,2)) - Y;

    Ssum = (Y_ba.*(D1-Xmf)).^2;

    RMSE(rate)=sqrt(sum(Ssum(:))/length(find(Y_ba==1)));
    MRE(rate) = sum(sum(abs(Y_ba.*D1-Y_ba.*Xmf)))./sum(sum(Y_ba.*D1));
end
sum(RMSE)