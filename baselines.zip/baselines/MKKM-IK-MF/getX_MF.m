function Xmf = getX_MF(Y,Idx,X)%%%%%%calculate Avg mtraix and Distance

    Xmf = zeros(size(X,1),size(X,2));
    
    X = Y.*X;
    [p1,p2] = find(Y==0);
    
    P = [p1,p2];
    
    for i = 1:length(P)
        AA = find(Idx==Idx(P(i,1)));
        if i==320
            a=0;
        end
        
        if ~isempty(find(Y(AA,P(i,2))==1))
            Xmf(P(i,1),P(i,2)) = sum(X(AA,P(i,2)))/length(find(Y(AA,P(i,2))==1));
        else
            
            Xmf(P(i,1),P(i,2)) = sum(X(:,P(i,2)))/length(find(Y(:,P(i,2))==1));
        end
    end
    

    
end