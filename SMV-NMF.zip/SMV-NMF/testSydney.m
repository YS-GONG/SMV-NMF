clear
clc

load('./datasets/Sydneyfull/Sydneyfull.mat');
%load('./datasets/ABSFull.mat');
%load('./datasets/Yall.mat');
load('./datasets/Sydneyfull/L.mat');
load('./datasets/Sydneyfull/DM.mat');
%load('./datasets/trainingData/TrainD.mat');


numclass = 10;%10  %12
sigma = 1;  %%%%%%% parameter of gaussian kernel %%%%
k = 30;        %%%%%%% latent dimension in nmf %%%%%%%  20%% 25 for transfer test
lambda1 = 2^-7;%-6%-7
lambda2 = 2^-8;%-5%-7
alpha = 2^-4;%-4%-6
lambda3 = 2^-6;%-5%-5

m = [size(D1,2), size(D2,2), size(D3,2), size(D4,2)];
D = [D1, D2, D3, D4];
% D = D(21:end,:);
% L_ba = L_ba(21:end,21:end);
%%%%%%%%%%%%%%%%%  normalization  %%%%%%%%%%%%%%%%
[D,ps] = mapminmax(D',0,10);
D = D';
Dv = D(:,[1:22,44:65,88:112,138:185]);
m1 = [22, 22, 25, 48];
Dt = D(:,[23:43,66:87,113:137,186:234]);
m2 = [21, 22, 25, 49];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
iter=1;
%for j = -10:1:-1
for i = 1:7
    %Y = Yall(:,:,i);
    Y = getmiss(Dv,i/10);
    %alpha = 2^j;
    [RMSE(i), MRE(i)]= runMyImputation(numclass,sigma,k,m1,lambda1,lambda2,alpha,lambda3,Dv,Y,L_ba,DM,2);
    
%     Y_ba = ones(size(Y,1),size(Y,2))-Y;
%     Ssum = (Y_ba.*(D-DH)).^2;
%     r_H(i)=sqrt(sum(Ssum(:))/length(find(Y_ba==1)));
    
%end

%Avg(iter) = mean(RMSE);
%iter=iter+1;
end







