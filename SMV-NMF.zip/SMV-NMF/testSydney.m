clear
clc
%%%%%  Due to the confidentiality agreement, we slightly modified the original data for an example%%%%

load('./datasets/Sydneyfull/Sydneyfull.mat');
load('./datasets/Sydneyfull/L.mat');
load('./datasets/Sydneyfull/DM.mat');



numclass = 10;
sigma = 1;  %%%%%%% parameter of gaussian kernel %%%%
k = 30;        %%%%%%% latent dimension in nmf %%%%%%%  
lambda1 = 2^-7;
lambda2 = 2^-8;
alpha = 2^-4;
lambda3 = 2^-6;

m = [size(D1,2), size(D2,2), size(D3,2), size(D4,2)];
D = [D1, D2, D3, D4];

%%%%%%%%%%%%%%%%%  normalization  %%%%%%%%%%%%%%%%
[D,ps] = mapminmax(D',0,10);
D = D';
Dv = D(:,[1:22,44:65,88:112,138:185]);
m1 = [22, 22, 25, 48];
Dt = D(:,[23:43,66:87,113:137,186:234]);
m2 = [21, 22, 25, 49];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
iter=1;

for i = 1:7

    Y = getmiss(Dv,i/10);

    [RMSE(i), MRE(i)]= runMyImputation(numclass,sigma,k,m1,lambda1,lambda2,alpha,lambda3,Dv,Y,L_ba,DM,2);
    

end







