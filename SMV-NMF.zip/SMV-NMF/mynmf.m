function [X_c,Y_ba] = mynmf(D,Y,k2,Z,ZZ,AvgX,XX,X2,la1,la2,la3,la4)
    rand('seed',0)
    e = 1e-4;
    K = k2;
    MAXITER = 500;
        N = size(D,1);
        M = size(D,2);    
        W = rand(N, K);
        H = rand(K, M);
    Y_ba = ones(size(Y,1),size(Y,2)) - Y;
    
    if nargin > 3
    
        

        L0 = norm(Y.*(D-W*H),'fro')+la1*norm(Y_ba.*Z.*(AvgX-W*H),'fro')+la2*norm(Y_ba.*ZZ.*(XX-W*H),'fro')+la3*norm(Y_ba.*(X2-W*H),'fro');%+la3*trace(W'*L_ba*W);%+la2*norm(W,'fro');


        for i=1:MAXITER

            W = W .* ((Y.*D*H')+la1*Y_ba.*Z.*AvgX*H'+la2*Y_ba.*ZZ.*XX*H'+la3*Y_ba.*X2*H')./((Y.*(W*H))*H'+la1*Y_ba.*Z.*(W*H)*H'+la2*Y_ba.*ZZ.*(W*H)*H'+la3*Y_ba.*(W*H)*H'+la4.*W+eps);%+la3*(2*L_ba*W)
            H = H .* (W'*(Y.*D)+la1*W'*(Y_ba.*Z.*AvgX)+la2*W'*(Y_ba.*ZZ.*XX)+la3*W'*(Y_ba.*X2))./(W'*(Y.*(W*H))+la1*W'*(Y_ba.*Z.*(W*H))+la2*W'*(Y_ba.*ZZ.*(W*H))+la3*W'*(Y_ba.*(W*H))+la4.*H+eps) ;
            L1 = norm(Y.*(D-W*H),'fro')+la1*norm(Y_ba.*Z.*(AvgX-W*H),'fro')+la2*norm(Y_ba.*ZZ.*(XX-W*H),'fro')+la3*norm(Y_ba.*(X2-W*H),'fro');%+la3*trace(W'*L_ba*W);
            Obj(i) = L1;
            LL = abs(L0-L1)/L0;
            if LL<e
                break
            end
            L0=L1;

        end
        X_c = W*H;

        plot(Obj);
    else


        L0 = norm(Y.*(D-W*H),'fro');

        for i=1:MAXITER

            W = W .* (Y.*D*H')./(Y.*(W*H)*H'+eps);
            H = H .* (W'*(Y.*D))./(W'*(Y.*(W*H))+eps) ;
            L1 = norm(Y.*(D-W*H),'fro');
            LL = abs(L0-L1)/L0;
            if LL<1e-1
                break
            end
            L0=L1;

        end
        X_c = W*H;
        %plot(L1);
    end
    
    
end