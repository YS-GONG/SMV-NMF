function [RMSE, MRE]= runMyImputation(numclass,sigma,k,m,lambda1,lambda2,alpha,lambda3,D,Y,L_ba,DM,la4)
%load('./datasets/trainingData/TrainD.mat');

Ynmis = ones(size(D,1),size(D,2));

    Y_ba = ones(size(Y,1),size(Y,2))-Y;
    nk =6;%4,5
    %[X1,~] = mynmf(D,Y,k);
    X2 = initialized_by_KNN(D,nk,Y,DM);
    %X2 = initialized_by_MF(D,Y);
    %X2 = zeros(size(D,1),size(D,2));
    DD = Y.*D+Y_ba.*X2;
    %%%%%%%%%%  clustering with incomplete data  %%%%%
    H = MKKMIK(DD,Ynmis,m,numclass,sigma,L_ba,alpha);

    [Idx,~,~,Distance] = kmeans(H,numclass);
    %DBI1 = myDBI(Idx,Ccenter,SumD);
    [Z,AvgX] = getDistandAvgX(Y,Idx,Distance,D,H);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%  clustering with incomplete data  %%%%%
    D_m = DD;
    Y_m = Y;
    for j = 1:length(m)
        H_m{j} = MKKMIK(D_m(:,1:m(j)),Ynmis,m(j),numclass,sigma,L_ba,alpha);
        [Idx_m{j},~,~,Distance_m{j}] = kmeans(H_m{j},numclass);
        [Z_m{j},AvgX_m{j}] = getDistandAvgX(Y_m(:,1:m(j)),Idx_m{j},Distance_m{j},D_m(:,1:m(j)),H_m{j});
    	D_m(:,1:m(j))=[];
        Y_m(:,1:m(j))=[];
    end
    ZZ = Z_m{1};
    XX = AvgX_m{1};
    if length(m)>1
        for z = 2:length(m)
            ZZ = [ZZ,Z_m{z}];
            XX = [XX,AvgX_m{z}];
        end
    end
    
    %X2 = DH;
    [X3,Y_ba] = mynmf(DD,Y,k,Z,ZZ,AvgX,XX,X2,lambda1,lambda2,lambda3,la4);
    X3(X3>10)=10;
    Ssum1 = (Y_ba.*(D-X3)).^2;

    RMSE=sqrt(sum(Ssum1(:))/length(find(Y_ba==1)));
    MRE= sum(sum(abs(Y_ba.*D-Y_ba.*X3)))./sum(sum(Y_ba.*D));
end