function S = getmisskernel(Y,m)

    num_k = size(m,2);
    Y1 = ones(size(Y,1),size(Y,2))-Y;
    
    
    for i = 1:num_k
        
        miss_s = find(sum(Y1(:,1:m(i)),2)>0);
        S{i}.indx = miss_s';
        Y1(:,1:m(i)) = [];
    end


end