function [Z,AvgX] = getDistandAvgX(Y,Idx,Distance,X,H)%%%%%%calculate Avg mtraix and Distance

    AvgX = zeros(size(X,1),size(X,2));
    Z = zeros(size(X,1),size(X,2));
    Z1 = zeros(size(X,1),size(X,2)); 
    Avg_x = zeros(1,size(X,2));
    
    for i = 1:length(unique(Idx))
        [~, p] = min(Distance(Idx==i,i));
        AA = find(Idx==i);
        u(i) = AA(p);
        D = pdist2(H(u(i),:),H(AA,:));
        D2 = pdist2(H(u(i),:),H);
        if sum(Y(u(i),:)) < size(Y,2)  %%%%%%% if there are missing data in ui
            P1 = find(Y(u(i),:)==0);
            P2 = find(Y(u(i),:)==1);
            Avg_x(1,P2) = X(u(i),P2);
             
            [~, P3] = sort(D);
            [~, P4] = sort(D2);
            
            Z(AA,:) = repmat(D',1,size(Y,2));
            
            
            for j = P1               %%%%%% if one feature missed in all samples in the same cluster
                if sum(Y(AA,j)) == 0                   
                    for k = P4(length(P3):end)
                        if Y(k,j)==1
                            Avg_x(1,j) = X(k,j);
                            Z1(u(i),j) = pdist2(H(u(i),:),H(k,:));
                            break
                        end
                    end
                    
                else                %%%%%% if one feature missed in apart of samples in the same cluster
                    for k = AA(P3(2:end))'
                        if Y(k,j)==1
                            Avg_x(1,j) = X(k,j);
                            Z(u(i),j) = Z(k,j);
                            break
                        end
                    end
                end
            end                       
            AvgX(AA,:) = repmat(Avg_x,length(AA),1);
            Z(Z1~=0)=Z1(Z1~=0);
        else
                AvgX(AA,:) = repmat(X(u(i),:),length(AA),1);
                Z(AA,:) = repmat(D',1,size(Y,2));
        end
            
    end
    
    Z = exp(-Z);
    
end