function H = center_norm2(KH,S)
%H = KH;

for i = 1:1:size(KH,3)
    B = zeros(size(KH,1));
    for j =1:1:length(S{i}.indx)
        B(S{i}.indx(j),:) = KH(S{i}.indx(j),:,i);
        B(:,S{i}.indx(j)) = KH(:,S{i}.indx(j),i);
    end
    H(:,:,i) = B;
end

for i = 1:1:size(KH,3)
    S1{i}.indx = sort(S{i}.indx);    
end

for i = 1:1:size(KH,3)
    S{i}.indx = sort(S{i}.indx,'descend'); 
end

for i = 1:1:size(KH,3)
    A=eye(size(KH,1)-length(S{i}.indx));
    L = ones(size(KH,1)-length(S{i}.indx));    
%     mis_indx = S{i}.indx;
%     obs_indx = setdiff(1:size(KH,1),mis_indx);
    KH1 = KH(:,:,i);
    for j =1:1:length(S{i}.indx)
        KH1(S{i}.indx(j),:) = [];
        KH1(:,S{i}.indx(j)) = [];
    end
    
    Kc = (A-L./size(A,1))*KH1*(A-L./size(A,1));

    D = diag(1./sqrt(diag(Kc)));
    K = D * Kc * D;
    
    for k =1:1:length(S1{i}.indx)
        K = [K(1:S1{i}.indx(k)-1,:);zeros(1,size(K,2));K(S1{i}.indx(k):end,:)];
        K = [K(:,1:S1{i}.indx(k)-1) zeros(size(K,1),1) K(:,S1{i}.indx(k):end)];
    end
    
    H(:,:,i) = H(:,:,i)+K;
    
    
end
end